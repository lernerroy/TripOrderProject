sap.ui.define(["sap/fe/core/AppComponent"], function(AppComponent) {
    'use strict';

    return AppComponent.extend("legstates.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
