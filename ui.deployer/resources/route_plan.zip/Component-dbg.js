sap.ui.define(['sap/fe/core/AppComponent'], function(AppComponent) {
    'use strict';

    return AppComponent.extend("route_plan.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
